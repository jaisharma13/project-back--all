<?php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php
       include 'dbconfig.php';
            $query = " SELECT * FROM video ORDER BY uploadfile DESC LIMIT 1";
            $result = mysqli_query($db, $query);
            while ($param = mysqli_fetch_assoc($result)) {
              $videoname  = $param['uploadfile'];
        
            }

?>

<div class="videoContainer">
        <!-- Add some extra attribute as video-url and mimetype which we can later play once we are done playing ads  -->
          <video id="video_1"  class="video-js playads" height="320px" width="420px" 
           mimetype="video/mp4" controls controlsList="nodownload" preload="none" 
           src="video/<?php echo $videoname ?>" type='video/mp4' >

        </video>

</div>
    
</body>
</html>

<?php
?>