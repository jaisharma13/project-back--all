
<!DOCTYPE html>
 
 <html>
  <head>
  <script src="https://code.jquery.com/jquery-2.2.0.min.js"></script>
  <script src="//oss.maxcdn.com/jquery.form/3.50/jquery.form.min.js"></script>
  <link rel='stylesheet' href='style.css' />
  </head>

  <style>

body{
 font-size:120%;
 line-height:2;
 font-family:calibri;
}
.formarea{
 width:60%;
 margin:0 auto;
 background-color:#788395; 
 text-align:center;
 padding:4%;
 border-radius:5px;
 height: 500px;
 margin-top: 50px;

}
 
#bararea{
  width: 100%;
    height: 35px;
    border: 2px solid #FFFFFF;
    margin-top: 22px;
}
 
#bar{
  width: 1%;
    margin: 4px 4px;
    height: 23px;
    background-color: #81f581;
}
 
#status{
 color:#ffffff;
}


</style>


  <body>


  <div class='formarea'>
  <h2>File Upload </h2>
  <form method='post' action='upload.php' enctype='multipart/form-data'>

  <input type="file"  id="fileupload" name="uploadfile" value="" required >
  <input  name="submit"  type="submit" value="submit"/>

  </form>

  <div id="bararea">
  <div id="bar"></div>
  </div>
  <div id='percent'></div>
  <div id='status'></div>
  </div>
          </div>

          </div>
  
  <script>
    
  
  $(function() {
  $(document).ready(function(){
  var bar = $('#bar')
  var percent = $('#percent');
  var status = $('#status');

  
  
  $('form').ajaxForm({
  beforeSend: function() {
  status.empty();
  var percentVal = '0%';
  bar.width(percentVal);
  percent.html(percentVal);
  },
  uploadProgress: function(event, position, total, percentComplete) {
  var percentVal = percentComplete + '%';
  console.log(percentVal);
  percent.html(percentVal);
  bar.width(percentVal);
  },
  complete: function(xhr) {
  status.html(xhr.responseText);
  window.location = "http://localhost/abc/video-progressbar/index-pop-up.php";

  }
  });
  });
  });
  </script>
  </body>
 </html>