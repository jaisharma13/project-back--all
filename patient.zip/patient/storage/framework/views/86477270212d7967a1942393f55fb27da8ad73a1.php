<!DOCTYPE html>

<html>

<head>

    <title></title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  

    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

</head>

<body>

   

<div class="container">

    <h2 align="center"></h2> 

   

    <form action="<?php echo e(url('addmore')); ?>"enctype="multipart/form-data" method="POST">
    <?php echo e(csrf_field()); ?> 


        <?php if($errors->any()): ?>

            <div class="alert alert-danger">

                <ul>

                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <li><?php echo e($error); ?></li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>

            </div>

        <?php endif; ?>

   
<?php if(Session::has('success')): ?>

<div class="alert alert-success text-center">

    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>

    <p><?php echo e(Session::get('success')); ?></p>

</div>

<?php endif; ?>
        <!-- <?php echo csrf_field(); ?> -->

        <tr>
        <!-- <td>   <lable>Patient Id</lable> <input type="text" name="pid" placeholder="PatientId" class="form-control" /> -->
        <!-- <lable>Patient Name</lable><input type="text" name="pname" placeholder="Name" class="form-control" /></td>   -->
</tr>

 <br>

</tr>
        <table class="table table-bordered" id="Table">  
            <tr>

                <th>Patient Id</th>
                <th>Process step Id</th>
                <th>Activity</th>
                <th>Stackholder</th>
                <th>No. of min</th>
                <th>Type/State</th>
                <th>Next step Id</th>
                <th>Action</th>

            </tr>
        
            <tr>  
            <td><input  id="pid" type="text" name="addmore[0][patientId]" placeholder="patientId" class="form-control" /></td>  
                <td><input type="text" name="addmore[0][processId]" placeholder="ProcessId" class="form-control" /></td>  

                <td><input type="text" name="addmore[0][activity]" placeholder="Activity" class="form-control" /></td>  

                <td> <select  class="form-control form-control-sm" name="addmore[0][stackholder]"  
                       data-style="form-control">
                           <option   value="---">---</option>
                           <option    value="Doctor">Doctor.</option>
                           <option    value="Nurse">Nurse</option>
                                                </select> </td>

           
                <td><input type="text" name="addmore[0][minutes]" placeholder="minutes." class="form-control" /></td> 

            
                <td> <select  class="form-control form-control-sm" name="addmore[0][state]"  
                       data-style="form-group">
                           <option    value="---">---</option>
                           <option    value="Start">Start</option>
                           <option   value="Process">Process</option>
                             <option     value="Decision">Decision</option>
                              <option   value="End">End</option>

                      </select> </td>

                      <td><input type="text" name="addmore[0][nextId]" placeholder="Next step Id" class="form-control" /></td>

               <td> <button type="button" class="btn btn-danger remove-tr">Remove</button></td></tr> 
                
            </tr>  
            
        </table> 
        <td><button type="button" name="add" id="add" class="btn btn-success">Add </button></td>  
        
        <button type="submit" class="btn btn-success">Save</button>



    </form>

</div>


<script type="text/javascript">

   
    var i = 0;

    $("#add").click(function(){
        ++i;

        $("#Table").append('<tr><td><input type="text" class="form-control form-control-sm location" name="addmore['+i+'][patientId]" placeholder="patientId" class="form-control" /></td><td><input type="text" name="addmore['+i+'][processId]" placeholder="ProcessId" class="form-control" /></td><td><input type="text" name="addmore['+i+'][activity]" placeholder="activity" class="form-control" /></td>  <td><select class="form-control form-control-sm" <option    value="---">---</option> <option    value="---">---</option> <option    value="Doctor">Doctor</option><option    value="Nurse">Nurse</option> name="addmore['+i+'][stackholder]"  class="form-control" /></td><td><input type="text" name="addmore['+i+'][minutes]" placeholder="minutes...." class="form-control" /></td><td> <select class="form-control form-control-sm"  <option  value="---">---</option>  <option  value="---">---</option> <option value="Start">Start</option> <option   value="Process">Process</option> <option     value="Decision">Decision</option><option   value="End">End</option> name="addmore['+i+'][state]"   value="option"   class="form-control" /></td><td><input type="text" name="addmore['+i+'][nextId]" placeholder="Next step Id" class="form-control" /></td>   <td> <button type="button" class="btn btn-danger remove-tr">Remove</button></td></tr>');

    });


    $(document).on('click', '.remove-tr', function(){  

         $(this).parents('tr').remove();

    });  

    $(function() {
    $('#pid').keyup(function() {
        var value = $(this).val();
        var val = $('.location').val(value);
        // $('#location-name1').val(value);
    }).keyup();
});

</script>

</script>

  

</body>

</html><?php /**PATH /var/www/html/patient/resources/views/patient.blade.php ENDPATH**/ ?>