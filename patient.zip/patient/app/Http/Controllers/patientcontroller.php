<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ProductStock;

class patientcontroller extends Controller
{


    public function addMore()
    {
        return view("patient");
    }


    public function addMorePost(Request $request)
    {

        $request->validate([
            'addmore.*.patientId' => 'required',
            'addmore.*.processId' => 'required',
            'addmore.*.activity' => 'required',
            'addmore.*.stackholder' => 'required',
            'addmore.*.minutes' => 'required',
            'addmore.*.state' => 'required',
            'addmore.*.nextId' => 'required',
        ]);
        
        
        foreach ($request->addmore as $key => $value) {
            ProductStock::create($value);
        }
        
        // print_r($value);die;

        return back()->with('success', 'Record Created Successfully.');
    }


    
}





