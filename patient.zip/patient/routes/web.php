<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\patientcontroller;
use App\Models\ProductStock;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('patient', [patientcontroller::class, 'addMore']);

Route::post('addmore', [patientcontroller::class, 'addMorePost']);
