<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="style.css">
    <script src="js/video.min.js"></script>
   <link href="//vjs.zencdn.net/5.4.6/video-js.min.css" rel="stylesheet">
   <script href="//vjs.zencdn.net/5.4.6/video.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs/dist/tf.min.js"> </script>


</head>

<body>
    
    
    <?php
           include 'config.php';
                $query = " SELECT * FROM video ORDER BY uploadfile desc LIMIT 1";
                $result = mysqli_query($db, $query);
                while ($param = mysqli_fetch_assoc($result)) {  
                  $videoname  = $param['uploadfile'];
                  //print_r($videoname);die;
                }
    
    ?>

<?php
        include 'config.php';

            $query = " SELECT * FROM overlayads ORDER BY ID DESC LIMIT 1";
            $result = mysqli_query($db, $query);
            while ($data = mysqli_fetch_assoc($result)) {
            $stime  = $data['stime'];
            $etime  = $data['etime'];
            $sectime = $data['sectime'];
            $endtime = $data['endtime'];
            $uploadfiles = $data['uploadfile'];
            $fileupload = $data['fileupload'];

    }


?>



    <div class="videoContainer">
        <!-- Add some extra attribute as video-url and mimetype which we can later play once we are done playing ads  -->
          <video id="video_1"  class="video-js playads" height="320px" width="420px" 
           mimetype="video/mp4" controls controlsList="nodownload" preload="none" 
           src="video/<?php echo $videoname ?>" type='video/mp4' >

        </video>
        
          <div class="moveToVideoJs">
              <img   class="advertisement hide" src="image/<?php echo $fileupload ?>" alt="">
              <div id="myModal">
                <button class="clsbtn" id="closeBtn">X</button>
                </div>
          </div>

          
          <div class="moveToVideo">
            <img   class="advertise hide" src="image/<?php echo $uploadfiles ?>" alt="">
            <div id="myMod">
              <button class="clsbtns" id="closeBtn">X</button>
              </div>
        </div>

        <div class="moveTo">
            <img   class="advert hide" src="image/crousal.jpg" alt="">
        </div>


        <div>
            <p id="time" > First overlay-ads Time </p>
            <p id="times" style="color:red;">  First Pop-up will we show after <?php echo $stime ?> sec </p>

            <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
            </div>
         </div>
         <div>
            <form action="uploads.php" method="POST" enctype="multipart/form-data">
               <label  id="label" for="stime">Start time:</label>
               &nbsp &nbsp <input type="text" id="stime" name="stime"> <br>  <br>
               <label id= "label"  for="etime">Delay time: </label>
               &nbsp <input type="text" id="etime" name="etime"><br>  <br>
               <input  type="file" name="fileupload" value=""  >  <br>


               <p id="time"  style="font-weight: 600;"> Second overlay-ads Time </p>
               <p id="times" style="color:red;">  Second Pop-up will we show after <?php echo $sectime ?> sec </p>


               <label  id="label" for="sectime">Start time:</label>
               &nbsp &nbsp <input type="text" id="sectime" name="sectime"> <br>  <br>
               <label id= "label"  for="endtime">Delay time: </label>
               &nbsp <input type="text" id="endtime" name="endtime"><br>  <br>

               <input  type="file" name="uploadfile" value=""  >  <br> <br>


               
                 <input style="margin-left: 115px;" name="submit"  type='submit'  value='Submit'>
               <!-- <button  style="margin-left: 115px;" type="button">Submit</button> -->
            </form>
         </div>
        </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>



    <script>


    $(document).ready(function() {
    localStorage.removeItem('pause');
    localStorage.removeItem('play');


    var videotag = $('.playads');
    var myPlayer = videojs('#video_1');
    var popup = $('.advertisement');
    var popups = $('.advertise');
    var overlays = $('.advert');

    $(".moveToVideoJs").appendTo($('#video_1'));
    $(".moveToVideo").appendTo($('#video_1'));
    $(".advert").appendTo($('#video_1'));
    
 //first pop-up display time 

    videotag.on("timeupdate", function tick(e) {
        if (e.target.currentTime >= <?php echo $stime ?>) {
            popup.addClass("show-popup").delay(<?php echo ($etime*1000)?>).fadeOut(100);
        }
    });

// video pause event 

    videotag.on("timeupdate", function ticks(e) {
        if (e.target.currentTime >= <?php echo $stime ?> ) {
            // console.log(e.target.currentTime);
        
         if(localStorage.getItem('pause')){
             return false;
            }

            this.pause();
            
            this.removeEventListener("timeupdate", ticks);

            setTimeout(function(){
                localStorage.setItem('pause','true');
                $('video').trigger('play');
            },<?php echo (($etime)*1000+100) ?>);

        } 

    });

//another pop-up display 
videotag.on("timeupdate", function tick(e) {
        if (e.target.currentTime >= <?php echo $sectime ?>) {
            popups.addClass("show-popups").delay(<?php echo ($endtime*1000)?> ).fadeOut(100);

        }
    });



  //  video 2nd pop-up pause 
  videotag.on("timeupdate", function ticks(e) {
        if (e.target.currentTime >= <?php echo $sectime ?>) {
        
         if(localStorage.getItem('play')){
             return false;
            }
            this.pause();
            this.removeEventListener("timeupdate", ticks);

            setTimeout(function(){
                localStorage.setItem('play','true');
                $('video').trigger('play');
                // this.play();
            },<?php echo(($endtime)*1000+100) ?>);

        } 
    });

    ///


    //3rd pop-up 

    videotag.on("timeupdate", function tick(e) {
        if (e.target.currentTime >= 34) {
            overlays.addClass("show-popuped").delay(1000).fadeOut(100);
        }
    });

// video pause event 

    videotag.on("timeupdate", function ticks(e) {
        if (e.target.currentTime >= 34 ) {
            // console.log(e.target.currentTime);
        
         if(localStorage.getItem('pause')){
             return true;
            }

            this.pause();
            this.removeEventListener("timeupdate", ticks);

            setTimeout(function(){
                localStorage.setItem('play','true');
                $('video').trigger('play');
            },2100);

        } 

    });



    // show advertisement label while play advertisement
    myPlayer.on('play', function() {
        if (myPlayer.hasClass("playads")) {
            $('.advertisement').removeClass('hide');
        }
    });

    myPlayer.on('play', function() {
        if (myPlayer.hasClass("playads")) {
            $('.advertise').removeClass('hide');
        }
    });

    myPlayer.on('play', function() {
        if (myPlayer.hasClass("playads")) {
            $('.advert').removeClass('hide');
        }
    });

    $("#closeBtn").click(function() {
        $('.moveToVideoJs').hide();
        $('.playads').trigger('pause');
        $('.playads').trigger('play');
    });

});




    </script>
    
  
</body>

</html>