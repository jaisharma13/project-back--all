<?php

include 'config.php';


$stime = $_POST['stime'];
$etime = $_POST['etime'];
$sectime = $_POST['sectime'];
$endtime = $_POST['endtime'];


error_reporting(0);

$msg = "";

// If upload button is clicked ...
if (isset($_POST['submit'])) {

	$uploadfile = $_FILES["uploadfile"]["name"];
	$tempname = $_FILES["uploadfile"]["tmp_name"];
	$folder = "image/". $uploadfile;
	
	$fileupload = $_FILES["fileupload"]["name"];
	$tempname = $_FILES["fileupload"]["tmp_name"];
	$folder = "image/". $fileupload;
	// print_r($folder);die;



	$sql = "INSERT INTO overlayads (stime, etime, sectime, endtime, uploadfile, fileupload) VALUES ('$stime', '$etime',  '$sectime', '$endtime',  '$uploadfile', '$fileupload')";

	mysqli_query($db, $sql);


// Now let's move the uploaded image into the folder: image
if (move_uploaded_file($tempname, $folder)) {



	echo "<h3> Image uploaded successfully!</h3>";
} 
else {
	echo "<h3> Failed to upload image!</h3>";
}
}


 header('location: index-pop-up.php');
?>
